var obfuscation_sidebar = '<h4>&nbsp;</h4>'+
'<a href="./Security_News.html"><img src="./images/news.jpg" alt="news.jpg" border="1"></a><br>'+
'<br>'+
'<h2>OpenPuff</h2><br>'+
'<a href="http://en.wikipedia.org/wiki/OpenPuff"><img src="./images/wikipedia.jpg" alt="wikipedia.jpg"></a><br>'+
'<br>'+
'<h2>P2P &amp; Torrent</h2><br>'+
'<a href="http://embeddedsw.net/p2p_torrent.html"><img src="./images/tntvillage.jpg" alt="tntvillage.jpg"></a><br>'+
'<br>'+
'<h2>Steganography</h2><br>'+
'<table><tr><td>'+
'<div class="left">'+
'<a class="darkgrey" href="http://en.wikipedia.org/wiki/Steganography_tools">Wikipedia - StegoTools</a><br>'+
'<a class="darkgrey" href="http://www.jjtc.com/Steganography/tools.html">jjtc.com - StegoTools</a><br>'+
'<a class="darkgrey" href="http://stegano.net/tools">stegano.net - StegoTools</a><br>'+
'</div>'+
'</td></tr></table>'+
'<br>'+
'<h2>Stegananalysis</h2><br>'+
'<table><tr><td>'+
'<div class="left">'+
'<a class="darkgrey" href="http://www.guillermito2.net/stegano/index.html">Stego-Hacking</a><br>'+
'<a class="darkgrey" href="http://www.spy-hunter.com/stegspydownload.htm">Spy-hunter.com</a><br>'+
'<a class="darkgrey" href="http://embeddedsw.net/doc/identifying_and_cracking_steganography_programs.pdf">Identify &amp; Crack</a><br>'+
'</div>'+
'</td></tr></table>'+
'<br>'+
'<h2>Obfuscation</h2><br>'+
'<table><tr><td>'+
'<div class="left">'+
'<a class="darkgrey" href="http://www.activism.net/cypherpunk/">Cypherpunk manifesto</a><br>'+
'<a class="darkgrey" href="http://web.archive.org/web/20110726185300/http://iq.org/~proff/rubberhose.org/">Rubberhose Crypto-FS</a><br>'+
'<a class="darkgrey" href="http://www.toad.com/gnu/">John Gilmore homepage</a><br>'+
'<a class="darkgrey" href="http://online.offshore.com.ai/security/">Cryptorebel</a><br>'+
'<a class="darkgrey" href="https://www.defcon.org/">Defcon.org</a><br>'+
'<a class="darkgrey" href="http://thenexthope.org/">Hackers on planet earth</a><br>'+
'<a class="darkgrey" href="http://www.s0ftpj.org/it/spj.html">Softproject 2003</a><br>'+
'</div>'+
'</td></tr></table>'+
'<br>'+
'<h2>OpenPuff Redist</h2><br>'+
'<a href="http://www.pendriveapps.com/steganography-and-watermarking-openpuff/"><img src="./images/pendriveapps.jpg" alt="pendriveapps.jpg"></a><br>'+
'<h4>&nbsp;</h4>'+
'<a href="http://portableapps.com/node/33493"><img src="./images/portableapps.jpg" alt="portableapps.jpg"></a><br>'+
'<h4>&nbsp;</h4>'+
'<a href="http://www.portablefreeware.com/index.php?id=1858"><img src="./images/portablefreeware.jpg" alt="portablefreeware.jpg"></a><br>'+
'<h4>&nbsp;</h4>'+
'<a href="http://www.winpenpack.com/main/download.php?view.913"><img src="./images/winpenpack.jpg" alt="winpenpack.jpg"></a><br>'+
'<br>'+
'<h2>MultiObfuscator Redist</h2><br>'+
'<a href="http://portableapps.com/node/33502"><img src="./images/portableapps.jpg" alt="portableapps.jpg"></a><br>'+
'<h4>&nbsp;</h4>'+
'<a href="http://www.portablefreeware.com/index.php?id=2130"><img src="./images/portablefreeware.jpg" alt="portablefreeware.jpg"></a><br>'+
'<br>';

document.write(obfuscation_sidebar);