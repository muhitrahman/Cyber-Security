var menu = '<ul>'+
'<li><a href="http://embeddedsw.net/"><span><b>Home</b></span></a></li>'+
'<li class="has-sub"><a><span><b>Software</b></span></a><ul>'+
' <li><a href="http://embeddedsw.net/OpenPuff_Steganography_Home.html"><span><b>OpenPuff</b><br><i>Steganography SW</i></span></a></li>'+
' <li><a href="http://embeddedsw.net/MultiObfuscator_Cryptography_Home.html"><span><b>MultiObfuscator</b><br><i>Cryptography SW</i></span></a></li>'+
' <li><a href="http://embeddedsw.net/libObfuscate_Cryptography_Home.html"><span><b>libObfuscate</b><br><i>Cryptography SW</i></span></a></li>'+
' <li class="last"><a href="http://embeddedsw.net/Cipher_Reference_Home.html"><span><b>256bit Ciphers</b><br><i>Reference Source</i></span></a></li></ul></li>'+
'<li class="has-sub"><a><span><b>Hardware</b></span></a><ul>'+
' <li><a href="http://embeddedsw.net/Obfuscated_Storage_Home.html"><span><b>Encrypted Storage</b><br><i>Obfuscation HW</i></span></a></li>'+
' <li><a href="http://embeddedsw.net/EMUFDD_Floppy_Hardware_Emulator_Home.html"><span><b>EMUFDD Floppy</b><br><i>Emulator HW</i></span></a></li>'+
' <li class="last"><a href="http://ilfema.it/"><span><b>FEMA Levelling</b><br><i>Automotive HW</i></span></a></li></ul></li>'+
'<li class="has-sub"><a><span><b>Resources</b></span></a><ul>'+
' <li><a href="http://embeddedsw.net/Security_News.html"><span><b>Security News</b><br><i>Cyber Security Threats</i></span></a></li>'+
' <li><a href="http://embeddedsw.net/p2p_torrent.html"><span><b>P2P &amp; Torrent</b><br><i>Shared Projects</i></span></a></li>'+
' <li><a href="http://embeddedsw.net/Extras_and_Links.html"><span><b>Extras &amp; Links</b><br><i>Projects of Interest</i></span></a></li>'+
' <li class="last"><a href="http://embeddedsw.net/Security_and_Humor.html"><span><b>Security &amp; Humor</b><br><i>Security Made Fun</i></span></a></li></ul></li>'+
'</ul>';

document.write(menu);